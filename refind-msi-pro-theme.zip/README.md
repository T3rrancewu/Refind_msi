# rEFInd MSI PRO Theme

This theme uses the `Creator_Common_1920x1080` PRO background extracted from the `7E82v1A41` MSI BIOS as the main rEFInd background.

## Layout

```text
themes/msi-pro/
  background.png
  icons/
  selection_big.png
  selection_small.png
  theme.conf
refind.conf.snippet
preview-msi-pro-refind.png
URSA-MAJOR-LICENSE
```

## Install

### Fedora after cloning from GitHub

```bash
sudo dnf install rEFInd efibootmgr git
sudo refind-install
git clone https://github.com/YOUR_USERNAME/refind-msi-pro-theme.git
cd refind-msi-pro-theme
sudo ./install-fedora.sh
```

If your ESP is not mounted at `/boot/efi`, pass it explicitly:

```bash
sudo ESP=/efi ./install-fedora.sh
```

### Manual install

1. Copy `themes/msi-pro` to `EFI/refind/themes/msi-pro` on your EFI partition.
2. Open `EFI/refind/refind.conf`.
3. Add this line:

```conf
include themes/msi-pro/theme.conf
```

4. Optionally merge the cleaner menu settings from `refind.conf.snippet`.

## Linux Icon Mapping

The theme includes specific distro icons and keeps the penguin only as the generic fallback:

```text
Fedora -> os_fedora.png
Ubuntu -> os_ubuntu.png
Mint   -> os_linuxmint.png
Arch   -> os_arch.png
Other Linux -> os_linux.png
```

rEFInd chooses icons by loader name, volume name, distro hint, or by a matching `.png` next to an `.efi` loader. If a distro does not auto-detect correctly, copy the desired icon beside its loader and give it the same base name as the `.efi` file.

Example:

```text
EFI/ubuntu/grubx64.efi
EFI/ubuntu/grubx64.png
```

Use these files from the theme:

```text
themes/msi-pro/icons/os_fedora.png
themes/msi-pro/icons/os_ubuntu.png
themes/msi-pro/icons/os_linuxmint.png
themes/msi-pro/icons/os_arch.png
themes/msi-pro/icons/os_linux.png
```

## Notes

- `background.png` is 1920x1080; `resolution 1920 1080` is recommended.
- The background includes a static top-center prompt: `Choose Your Operating System`.
- `icons/` comes from `kgoettler/ursamajor-rEFInd`.
- `selection_big.png` and `selection_small.png` are tuned for the light MSI PRO background.
- rEFInd has limited exact positioning for the OS selection row, so this theme uses the default rEFInd layout over a full-screen background.
- `preview-msi-pro-refind.png` is only a visual mockup, not a runtime theme file.

## Icon Source

System icons are based on and copied from:

```text
https://github.com/kgoettler/ursamajor-rEFInd
```

The original project license is copied as `URSA-MAJOR-LICENSE`.

## Push This Theme to GitHub

Create an empty GitHub repository named `refind-msi-pro-theme`, then run these commands from this directory:

```bash
git init
git add .
git commit -m "Add MSI PRO rEFInd theme"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/refind-msi-pro-theme.git
git push -u origin main
```
