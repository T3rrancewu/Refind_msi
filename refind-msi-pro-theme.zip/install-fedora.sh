#!/usr/bin/env bash
set -euo pipefail

THEME_NAME="msi-pro"
ESP="${ESP:-/boot/efi}"
REFIND_DIR="$ESP/EFI/refind"
THEME_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/themes/$THEME_NAME"
THEME_DST="$REFIND_DIR/themes/$THEME_NAME"
CONF="$REFIND_DIR/refind.conf"
INCLUDE_LINE="include themes/$THEME_NAME/theme.conf"

if [[ $EUID -ne 0 ]]; then
  echo "Please run with sudo:"
  echo "  sudo ESP=$ESP $0"
  exit 1
fi

if [[ ! -d "$THEME_SRC" ]]; then
  echo "Theme source not found: $THEME_SRC"
  exit 1
fi

if [[ ! -d "$REFIND_DIR" ]]; then
  echo "rEFInd directory not found: $REFIND_DIR"
  echo "Install rEFInd first, for example:"
  echo "  sudo dnf install rEFInd efibootmgr"
  echo "  sudo refind-install"
  exit 1
fi

mkdir -p "$REFIND_DIR/themes"
rm -rf "$THEME_DST"
cp -a "$THEME_SRC" "$THEME_DST"

if [[ ! -f "$CONF" ]]; then
  echo "rEFInd config not found: $CONF"
  exit 1
fi

backup="$CONF.bak.$(date +%Y%m%d-%H%M%S)"
cp -a "$CONF" "$backup"

if ! grep -Fxq "$INCLUDE_LINE" "$CONF"; then
  printf '\n%s\n' "$INCLUDE_LINE" >> "$CONF"
fi

echo "Installed theme to: $THEME_DST"
echo "Config backup: $backup"
echo "Done. Reboot to see the theme."
